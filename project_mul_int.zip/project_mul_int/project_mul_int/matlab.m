clc
A = randi([0 9], 4, 9);
B = randi([0 9], 9, 3);
C = A*B;  

AHex = dec2hex(A', 8);
BHex = dec2hex(B', 8);
CHex = dec2hex(C', 24);
% end